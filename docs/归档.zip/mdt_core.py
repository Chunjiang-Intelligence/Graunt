import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import os
import math
import triton
import triton.language as tl
from typing import Optional

try:
    from flash_attn import flash_attn_func
    FLASH_ATTENTION_AVAILABLE = True
    print("Flash Attention 2 available. Using for optimized attention.")
except ImportError:
    FLASH_ATTENTION_AVAILABLE = False
    print("Flash Attention 2 not found. Using PyTorch's default attention.")

@triton.jit
def cayley_implicit_kernel(
    g_ptr, omega_ptr, eta_ptr, g_corr_ptr,
    n_elements, m_planes,
    BLOCK_SIZE: tl.constexpr
):
    pid = tl.program_id(axis=0)
    offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < (n_elements * m_planes)
    
    g_offset_0 = offsets * 2
    g_offset_1 = offsets * 2 + 1
    
    g0 = tl.load(g_ptr + g_offset_0, mask=mask)
    g1 = tl.load(g_ptr + g_offset_1, mask=mask)
    omega = tl.load(omega_ptr + offsets, mask=mask)
    
    token_head_idx = offsets // m_planes
    eta = tl.load(eta_ptr + token_head_idx, mask=mask)
    
    eta_w = eta * omega
    denom = 1.0 / (1.0 + eta_w * eta_w)
    
    g_corr0 = denom * (g0 - eta_w * g1)
    g_corr1 = denom * (eta_w * g0 + g1)
    
    tl.store(g_corr_ptr + g_offset_0, g_corr0, mask=mask)
    tl.store(g_corr_ptr + g_offset_1, g_corr1, mask=mask)

def apply_cayley_implicit(g, omega, eta, m_planes):
    B, T, H, D = g.shape
    g_corr = torch.empty_like(g)
    n_elements = B * T * H
    grid = lambda meta: (triton.cdiv(n_elements * m_planes, meta['BLOCK_SIZE']),)
    
    cayley_implicit_kernel[grid](
        g, omega.contiguous(), eta.contiguous(), g_corr,
        n_elements, m_planes,
        BLOCK_SIZE=1024
    )
    return g_corr

def lift_minimal_coords(s):
    sum_s = -s.sum(dim=-1, keepdim=True)
    return torch.cat([s, sum_s], dim=-1)

def gauge_fix(g):
    return g - g.mean(dim=-1, keepdim=True)

def solve_kl_step_newton(u, g, kappa, max_iter=2, epsilon=1e-8):
    u_fp32 = u.to(torch.float32)
    g_fp32 = g.to(torch.float32)
    
    pi = F.softmax(u_fp32, dim=-1)
    var_g = torch.sum(pi * (g_fp32 ** 2), dim=-1) - (torch.sum(pi * g_fp32, dim=-1))**2
    eta = torch.sqrt(2 * kappa / (var_g.clamp(min=epsilon))).unsqueeze(-1)
    
    for _ in range(max_iter):
        u_plus = u_fp32 + eta * g_fp32
        pi_plus = F.softmax(u_plus, dim=-1)
        expected_g_plus = torch.sum(pi_plus * g_fp32, dim=-1, keepdim=True)
        A_eta = torch.logsumexp(u_plus, dim=-1, keepdim=True)
        A_0 = torch.logsumexp(u_fp32, dim=-1, keepdim=True)
        kl_val = eta * expected_g_plus - (A_eta - A_0)
        
        var_g_plus = torch.sum(pi_plus * (g_fp32 ** 2), dim=-1, keepdim=True) - expected_g_plus**2
        derivative = eta * var_g_plus.clamp(min=epsilon)
        eta = F.relu(eta - (kl_val - kappa) / derivative)
    return eta.to(u.dtype)

class RoPE(nn.Module):
    def __init__(self, dim, max_seq_len=8192, base=10000):
        super().__init__()
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2).float() / dim))
        t = torch.arange(max_seq_len, dtype=torch.float32)
        freqs = torch.einsum("i,j->ij", t, inv_freq)
        self.register_buffer("sin", torch.sin(freqs), persistent=False)
        self.register_buffer("cos", torch.cos(freqs), persistent=False)

    def forward(self, x):
        seq_len = x.shape[-2]
        cos = self.cos[:seq_len]
        sin = self.sin[:seq_len]
        
        x_reshaped = x.float().reshape(*x.shape[:-1], -1, 2)
        x_rotated = torch.stack([-x_reshaped[..., 1], x_reshaped[..., 0]], dim=-1).flatten(-2)
        
        return (x * cos + x_rotated * sin).to(x.dtype)

class MDTAttention(nn.Module):
    def __init__(self, d_model, n_heads, n_kv_heads):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_kv_heads = n_kv_heads
        self.n_rep = n_heads // n_kv_heads
        self.d_head = d_model // n_heads
        self.m_planes = self.d_head // 2
        
        self.W_q = nn.Linear(d_model, d_model, bias=False)
        self.W_k = nn.Linear(d_model, n_kv_heads * self.d_head, bias=False)
        self.W_v = nn.Linear(d_model, n_kv_heads * self.d_head, bias=False)
        self.W_o = nn.Linear(d_model, d_model, bias=False)
        
        self.rope = RoPE(self.d_head)
        self.omega_mlp = nn.Sequential(
            nn.Linear(self.m_planes + 6, 32),
            nn.SiLU(),
            nn.Linear(32, self.m_planes)
        )
        self.omega_max = 5.0

    def forward(self, x_feat, u_geom, m_slow, kappa=0.01, beta=0.9, chi=0.1):
        B, T, _ = x_feat.shape
        q = self.W_q(x_feat).view(B, T, self.n_heads, self.d_head)
        k = self.W_k(x_feat).view(B, T, self.n_kv_heads, self.d_head)
        v = self.W_v(x_feat).view(B, T, self.n_kv_heads, self.d_head)
        
        q = self.rope(q)
        k = self.rope(k)
        
        k_exp = k.repeat_interleave(self.n_rep, dim=2)
        v_exp = v.repeat_interleave(self.n_rep, dim=2)
        
        if FLASH_ATTENTION_AVAILABLE:
            y = flash_attn_func(q, k_exp, v_exp, causal=True).view(B, T, self.d_model)
            with torch.no_grad():
                scores = torch.einsum('bthd,bshd->bhts', q, k_exp) / math.sqrt(self.d_head)
                mask = torch.triu(torch.ones(T, T, device=x_feat.device, dtype=torch.bool), diagonal=1)
                scores = scores.masked_fill(mask, -float('inf'))
                alpha = F.softmax(scores, dim=-1).detach()
        else:
            scores = torch.einsum('bthd,bshd->bhts', q, k_exp) / math.sqrt(self.d_head)
            mask = torch.triu(torch.ones(T, T, device=x_feat.device, dtype=torch.bool), diagonal=1)
            scores = scores.masked_fill(mask, -float('inf'))
            alpha = F.softmax(scores, dim=-1)
            y = torch.einsum('bhts,bshd->bthd', alpha, v_exp).reshape(B, T, self.d_model)
        
        e_att = self.W_o(y).view(B, T, self.n_heads, self.d_head)
        delta_s = e_att[..., :-1]
        
        cos_sim = F.relu(torch.sum(F.normalize(delta_s, dim=-1) * F.normalize(m_slow, dim=-1), dim=-1, keepdim=True))
        g_raw_s = delta_s + cos_sim * m_slow
        g_u = lift_minimal_coords(g_raw_s)
        
        pi = F.softmax(u_geom, dim=-1)
        g = gauge_fix((1e-5 + pi * (1 - pi)) * g_u)
        
        H = -torch.sum(alpha * torch.log(alpha + 1e-12), dim=-1)
        c = torch.sum(alpha**2, dim=-1)
        a_max, _ = torch.max(alpha, dim=-1)
        q_norm = torch.norm(q, dim=-1)
        y_norm = torch.norm(e_att, dim=-1)
        qy_dot = torch.sum(q * e_att, dim=-1)
        
        v_tilde = v_exp.view(B, T, self.n_heads, self.m_planes, 2)
        k_tilde = k_exp.view(B, T, self.n_heads, self.m_planes, 2)
        delta_jk = v_tilde[..., 0]*k_tilde[..., 1] - v_tilde[..., 1]*k_tilde[..., 0]
        
        diag_feats = torch.stack([H, c, a_max, q_norm, y_norm, qy_dot], dim=-1)
        omega_in = torch.cat([delta_jk, diag_feats], dim=-1)
        omega = self.omega_max * torch.tanh(self.omega_mlp(omega_in) / self.omega_max)
        
        eta_0 = solve_kl_step_newton(u_geom, g, kappa)
        
        g_corr = apply_cayley_implicit(g.view(B, T, self.n_heads, self.m_planes, 2), omega, eta_0.squeeze(-1), self.m_planes)
        g_corr = g_corr.view(B, T, self.n_heads, self.d_head)
        g_corr = gauge_fix(g_corr)
        
        eta_final = solve_kl_step_newton(u_geom, g_corr, kappa)
        
        u_out = u_geom + eta_final * g_corr
        
        m_out = beta * m_slow + delta_s
        m_out = (1 - chi) * m_out
        
        return u_out, m_out

class LSHSparseMoEAsync(nn.Module):
    def __init__(self, d_model, num_experts, d_inner, mmap_path=None):
        super().__init__()
        self.d_model, self.num_experts, self.d_inner = d_model, num_experts, d_inner
        self.register_buffer("hash_vectors", torch.randn(d_model, 16), persistent=False)
        self.mmap_path = mmap_path
        if mmap_path and os.path.exists(mmap_path):
            self.expert_weights = np.memmap(mmap_path, dtype='int8', mode='r', shape=(num_experts, d_inner, d_model))
            self.quant_scale = np.memmap(mmap_path+".scale", dtype='float32', mode='r', shape=(num_experts,))
        else: self.expert_weights = None
        self.prefetch_stream = torch.cuda.Stream()
        self.expert_cache = {}

    def prefetch(self, x):
        if self.expert_weights is None: return None
        with torch.cuda.stream(self.prefetch_stream):
            hashes = torch.sign(x @ self.hash_vectors)
            expert_ids = ((hashes > 0).long() * (2 ** torch.arange(16, device=x.device))).sum(dim=-1) % self.num_experts
            unique_ids = torch.unique(expert_ids).cpu().numpy()
            for e_id in unique_ids:
                if e_id not in self.expert_cache:
                    w_int8_pinned = torch.from_numpy(self.expert_weights[e_id]).pin_memory()
                    scale = self.quant_scale[e_id]
                    w_gpu = w_int8_pinned.to(x.device, non_blocking=True)
                    self.expert_cache[e_id] = (w_gpu.float() * scale).to(x.dtype)
        return expert_ids

    def forward(self, x, expert_ids=None):
        B, T, D = x.shape
        out = torch.zeros_like(x)
        if expert_ids is None:
            hashes = torch.sign(x @ self.hash_vectors)
            expert_ids = ((hashes > 0).long() * (2 ** torch.arange(16, device=x.device))).sum(dim=-1) % self.num_experts
        if self.expert_weights is not None:
             torch.cuda.current_stream().wait_stream(self.prefetch_stream)
        
        unique_experts = torch.unique(expert_ids)
        for e_id_tensor in unique_experts:
            e_id = e_id_tensor.item()
            mask = (expert_ids == e_id)
            if self.expert_weights is not None:
                w_fp16 = self.expert_cache.get(e_id)
            else: w_fp16 = torch.randn(self.d_inner, self.d_model, device=x.device, dtype=x.dtype)
            hidden = F.gelu(x[mask] @ w_fp16.T)
            out[mask] = hidden @ w_fp16
        self.expert_cache.clear()
        return out

class ModernMDTBlock(nn.Module):
    def __init__(self, d_model, n_heads, n_kv_heads, num_experts, d_inner, mmap_path):
        super().__init__()
        self.attn = MDTAttention(d_model, n_heads, n_kv_heads)
        self.moe = LSHSparseMoEAsync(d_model, num_experts, d_inner, mmap_path)
        
        self.attn_norm = nn.RMSNorm(d_model)
        self.ffn_norm = nn.RMSNorm(d_model)
        
        self.w1 = nn.Linear(d_model, d_inner, bias=False)
        self.w2 = nn.Linear(d_inner, d_model, bias=False)
        self.w3 = nn.Linear(d_model, d_inner, bias=False)
        
    def forward(self, u_geom, m_att, m_ffn):
        x_feat_attn = self.attn_norm(u_geom.flatten(start_dim=2))
        
        expert_ids = self.moe.prefetch(x_feat_attn)
        
        u_after_attn, m_att = self.attn(x_feat_attn, u_geom, m_att)
        
        x_feat_ffn = self.ffn_norm(u_after_attn.flatten(start_dim=2))
        
        moe_out = self.moe(x_feat_ffn, expert_ids)
        gate = self.w1(x_feat_ffn)
        e_ffn_raw = self.w2(F.silu(gate) * moe_out)
        e_ffn = e_ffn_raw.view(u_geom.shape)
        
        delta_s_ffn = e_ffn[..., :-1]
        m_ffn = 0.9 * m_ffn + delta_s_ffn
        g_ffn = gauge_fix(lift_minimal_coords((1-0.1)*m_ffn))
        eta_ffn = solve_kl_step_newton(u_after_attn, g_ffn, kappa=0.01)
        u_final = u_after_attn + eta_ffn * g_ffn
        
        return u_final, m_att, m_ffn

class CredalTransformerV2(nn.Module):
    def __init__(self, vocab_size=32000, d_model=2048, n_heads=16, n_kv_heads=4, n_layers=24, num_experts=100000, mmap_path=None):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_head = d_model // n_heads
        
        self.tok_emb = nn.Embedding(vocab_size, d_model)
        self.layers = nn.ModuleList([
            ModernMDTBlock(d_model, n_heads, n_kv_heads, num_experts, d_inner=8192, mmap_path=mmap_path)
            for _ in range(n_layers)
        ])
        self.final_norm = nn.RMSNorm(d_model)
        self.lm_head = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, input_ids: torch.Tensor):
        B, T = input_ids.shape
        x = self.tok_emb(input_ids) * math.sqrt(self.d_model) # Gemma-style scaling
        s_geom_init = torch.zeros(B, T, self.n_heads, self.d_head - 1, device=x.device, dtype=x.dtype)
        u_geom = lift_minimal_coords(s_geom_init) + x.view(B, T, self.n_heads, self.d_head)
        
        m_att = torch.zeros_like(s_geom_init)
        m_ffn = torch.zeros_like(s_geom_init)
        for layer in self.layers:
            u_geom, m_att, m_ffn = layer(u_geom, m_att, m_ffn)
        final_h = self.final_norm(u_geom.flatten(start_dim=2))
        logits = self.lm_head(final_h)
        return logits