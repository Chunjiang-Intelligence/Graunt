import torch
import torch.nn.functional as F
import numpy as np
import rocksdb
import os
import shutil
import time
import math
import multiprocessing as mp
from vllm import LLM, SamplingParams
from tqdm import tqdm
from concurrent.futures import ProcessPoolExecutor, as_completed
from datasets import load_dataset 

class InfraConfig:
    NUM_EXPERTS = 100000
    D_MODEL = 2048
    D_INNER = 8192
    TEACHER_MODEL = "Qwen/Qwen2-7B"
    BATCH_SIZE = 512
    ROCKSDB_PATH = "./expert_vault_rocksdb"
    MEMMAP_FILE = "mdt_68b_experts.dat"
    TOKEN_GOAL = 50_000_000_000 # 50B Tokens
    MAX_SEQ_LEN = 1024

torch.manual_seed(42)
HASH_VECTORS = torch.randn(InfraConfig.D_MODEL, 16).to("cuda").half()
POWERS = (2 ** torch.arange(16)).to("cuda").to(torch.long)

class GPUFeatureProducer:
    def __init__(self, config):
        self.config = config
        self.llm = LLM(
            model=config.TEACHER_MODEL, 
            enforce_eager=True, 
            gpu_memory_utilization=0.7,
            max_model_len=config.MAX_SEQ_LEN
        )
        
        self.proj_in = torch.randn(3584, config.D_MODEL).to("cuda").half()
        self.proj_out = torch.randn(3584, config.D_MODEL).to("cuda").half()

    def process_batch(self, batch_prompts):
        outputs = self.llm.encode(batch_prompts)
        
        batch_payload = []
        for out in outputs:
            h = torch.tensor(out.outputs.hidden_states[-1]).to("cuda").half() # [T, 3584]
            # zero copy
            z = h @ self.proj_in # [T, 2048]
            y = h @ self.proj_out # [T, 2048]
            # LSH 路由
            binary_codes = (z @ HASH_VECTORS > 0).to(torch.long)
            expert_ids = (binary_codes * POWERS).sum(dim=-1) % self.config.NUM_EXPERTS
            
            # 转为 CPU 字节流准备入库
            # [Expert_ID (4B), Z_ptr (2048*2B), Y_ptr (2048*2B)]
            expert_ids_cpu = expert_ids.cpu().numpy()
            z_cpu = z.cpu().numpy().astype(np.float16)
            y_cpu = y.cpu().numpy().astype(np.float16)
            
            for i in range(len(expert_ids_cpu)):
                batch_payload.append((
                    expert_ids_cpu[i], 
                    z_cpu[i].tobytes(), 
                    y_cpu[i].tobytes()
                ))
        return batch_payload

class RocksStorage:
    def __init__(self, path):
        opts = rocksdb.Options()
        opts.create_if_missing = True
        opts.max_open_files = 5000
        opts.write_buffer_size = 256 * 1024 * 1024 # 256MB 写缓冲
        opts.max_write_buffer_number = 4
        opts.target_file_size_base = 128 * 1024 * 1024
        
        self.db = rocksdb.DB(path, opts)

    def commit_batch(self, payload):
        batch = rocksdb.WriteBatch()
        for eid, z_bytes, y_bytes in payload:
            key = f"e{eid:06d}".encode()
            existing = self.db.get(key)
            new_val = (existing if existing else b"") + z_bytes + y_bytes
            batch.put(key, new_val)
        self.db.write(batch)

def fista_worker(eid, raw_bytes):
    stride = InfraConfig.D_MODEL * 2 * 2 
    num_samples = len(raw_bytes) // stride
    if num_samples < 50: return None, 1.0 # 样本太少不具代表性
    
    data = np.frombuffer(raw_bytes, dtype=np.float16).reshape(num_samples, 2, InfraConfig.D_MODEL)
    Z = torch.from_numpy(data[:, 0, :].astype(np.float32))
    Y = torch.from_numpy(data[:, 1, :].astype(np.float32))

    # SVD 主子空间投影
    U, S, V = torch.svd(Z)
    V_sub = V[:, :InfraConfig.D_INNER]
    Z_proj = Z @ V_sub
    
    # FISTA 闭式求解
    W = torch.zeros(V_sub.shape[1], InfraConfig.D_MODEL)
    ZTZ = Z_proj.T @ Z_proj
    ZTY = Z_proj.T @ Y
    L = torch.linalg.norm(ZTZ, ord=2).item() + 1e-7
    
    for _ in range(80):
        grad = ZTZ @ W - ZTY
        W_prev = W
        W = torch.sign(W - grad/L) * torch.relu(torch.abs(W - grad/L) - 0.005/L)
        if torch.norm(W - W_prev) < 1e-4: break

    scale = (torch.max(torch.abs(W)) / 127.0).item() + 1e-9
    W_int8 = torch.clamp(torch.round(W / scale), -127, 127).to(torch.int8)
    return eid, W_int8.numpy(), scale

def run_infra_x_compiler():
    conf = InfraConfig()
    print(">>> Initializing...")
    producer = GPUFeatureProducer(conf)
    storage = RocksStorage(conf.ROCKSDB_PATH)
    
    dataset = load_dataset("allenai/c4", "en", split="train", streaming=True)
    
    start_time = time.time()
    processed_tokens = 0
    batch_prompts = []
    
    pbar = tqdm(total=conf.TOKEN_GOAL, desc="Token Extraction")
    for item in dataset:
        batch_prompts.append(item['text'][:1024])
        if len(batch_prompts) >= conf.BATCH_SIZE:
            payload = producer.process_batch(batch_prompts)
            storage.commit_batch(payload)
            
            processed_tokens += len(batch_prompts) * 512 
            pbar.update(len(batch_prompts) * 512)
            batch_prompts = []
            
        if processed_tokens >= conf.TOKEN_GOAL: break
    pbar.close()
    
    print(">>> Initializing Consumer (Global FISTA)...")
    expert_mmap = np.memmap(conf.MEMMAP_FILE, dtype='int8', mode='w+', shape=(conf.NUM_EXPERTS, conf.D_INNER, conf.D_MODEL))
    scale_mmap = np.memmap(conf.MEMMAP_FILE + ".scale", dtype='float32', mode='w+', shape=(conf.NUM_EXPERTS,))
    
    with ProcessPoolExecutor(max_workers=mp.cpu_count()) as executor:
        futures = []
        it = storage.db.iteritems()
        it.seek_to_first()
        
        for key, value in tqdm(it, desc="Queueing FISTA Jobs"):
            eid = int(key.decode()[1:])
            futures.append(executor.submit(fista_worker, eid, value))
        
        for future in tqdm(as_completed(futures), total=len(futures), desc="Solving Experts"):
            eid, w_int8, scale = future.result()
            if w_int8 is not None:
                expert_mmap[eid] = w_int8
                scale_mmap[eid] = scale

    expert_mmap.flush()
    duration = (time.time() - start_time) / 3600
    print(f">>> Compilation Finished. Total Time: {duration:.2f} hours.")

if __name__ == "__main__":
    run_infra_x_compiler()