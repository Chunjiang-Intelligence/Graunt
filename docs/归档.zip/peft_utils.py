import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from peft import get_peft_model, LoraConfig, TaskType

class DoRALinear(nn.Module):
    """
    DoRA (Weight-Decomposed Low-Rank Adaptation) a nn.Linear layer.
    This is a simplified implementation for demonstration. For production,
    using the official `peft` library's support is recommended once available.
    Reference: https://arxiv.org/abs/2402.09353
    """
    def __init__(self, base_layer, r=16, alpha=32, dropout=0.05):
        super().__init__()
        self.r = r
        self.alpha = alpha
        self.scaling = alpha / r

        self.in_features = base_layer.in_features
        self.out_features = base_layer.out_features

        self.lora_A = nn.Parameter(torch.empty(r, self.in_features))
        self.lora_B = nn.Parameter(torch.empty(self.out_features, r))
        self.m = nn.Parameter(torch.empty(self.out_features, 1))
        self.dropout = nn.Dropout(dropout)
        self.base_layer = base_layer

        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B)
        nn.init.ones_(self.m)

    def forward(self, x: torch.Tensor):
        W0 = self.base_layer.weight.detach()
        lora_update = self.lora_B @ self.lora_A
        adapted_W = W0 + self.dropout(lora_update) * self.scaling
        norm_adapted_W = torch.norm(adapted_W, p=2, dim=1, keepdim=True)
        final_W = (self.m / (norm_adapted_W + 1e-8)) * adapted_W
        
        return F.linear(x, final_W, self.base_layer.bias)

def apply_peft(model, peft_method='lora', r=16, alpha=32, target_modules=None):
    if target_modules is None:
        target_modules = ["W_q", "W_v"]

    if peft_method.lower() == 'lora':
        peft_config = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            r=r,
            lora_alpha=alpha,
            lora_dropout=0.05,
            target_modules=target_modules,
        )
        model = get_peft_model(model, peft_config)
        model.print_trainable_parameters()
        return model
    
    elif peft_method.lower() == 'dora':
        print("Applying DoRA manually...")
        total_params = 0
        trainable_params = 0
        for name, module in model.named_modules():
            if any(target in name for target in target_modules) and isinstance(module, nn.Linear):
                parent_name = '.'.join(name.split('.')[:-1])
                child_name = name.split('.')[-1]
                parent_module = model.get_submodule(parent_name)
                
                new_layer = DoRALinear(module, r=r, alpha=alpha)
                setattr(parent_module, child_name, new_layer)
        
        for name, param in model.named_parameters():
            if 'lora' in name or 'm' in name:
                param.requires_grad = True
                trainable_params += param.numel()
            else:
                param.requires_grad = False
            total_params += param.numel()
            
        print(f"DoRA applied. Trainable params: {trainable_params} || Total params: {total_params} || Trainable %: {100 * trainable_params / total_params:.4f}")
        return model
    
    else:
        raise ValueError(f"Unknown PEFT method: {peft_method}")