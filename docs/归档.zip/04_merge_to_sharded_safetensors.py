import torch
import numpy as np
import os
import json
import argparse
from safetensors.torch import save_file, save_model
from tqdm import tqdm
from mdt_core import CredalTransformerV2, lift_minimal_coords

def stream_merge_to_shards(config):
    print(f"Starting Sharded Merge. Target Directory: {config.output_dir}")
    os.makedirs(config.output_dir, exist_ok=True)

    device = "cpu"

    print(f"Loading active weights from {config.active_weights_path}...")
    active_sd = torch.load(config.active_weights_path, map_location=device)

    print("Mapping static dictionary from SSD...")
    expert_weights_int8 = np.memmap(
        config.static_dict_path, 
        dtype='int8', 
        mode='r', 
        shape=(config.num_experts, config.d_inner, config.d_model)
    )
    expert_scales = np.memmap(
        config.static_dict_path + ".scale", 
        dtype='float32', 
        mode='r', 
        shape=(config.num_experts,)
    )

    layers_per_shard = 2
    weight_map = {}

    total_shards = config.n_layers // layers_per_shard
    
    base_sd = {k: v for k, v in active_sd.items() if "layers." not in k}
    shard_0_name = "model-00001-of-target.safetensors"
    save_file(base_sd, os.path.join(config.output_dir, shard_0_name))
    for k in base_sd.keys(): weight_map[k] = shard_0_name
    del base_sd

    shard_count = 2
    for start_layer in range(0, config.n_layers, layers_per_shard):
        end_layer = min(start_layer + layers_per_shard, config.n_layers)
        current_shard_sd = {}
        shard_name = f"model-{shard_count:05d}-of-{total_shards+1:05d}.safetensors"
        
        print(f"\nProcessing Shard {shard_count}: Layers {start_layer} to {end_layer-1}")
        
        for i in range(start_layer, end_layer):
            layer_prefix = f"layers.{i}."
            layer_active = {k: v for k, v in active_sd.items() if k.startswith(layer_prefix)}
            current_shard_sd.update(layer_active)
            
            for e_id in tqdm(range(config.num_experts), desc=f"Layer {i} static weights", leave=False):
                w_int8 = torch.from_numpy(expert_weights_int8[e_id])
                scale = torch.tensor(expert_scales[e_id])
                
                w_bf16 = (w_int8.to(torch.float32) * scale).to(torch.bfloat16)
                
                key = f"layers.{i}.moe.experts.{e_id}.weight"
                current_shard_sd[key] = w_bf16
                
                if e_id % 10000 == 0:
                    pass

        print(f"Writing {shard_name} to SSD...")
        save_file(current_shard_sd, os.path.join(config.output_dir, shard_name))
        
        for k in current_shard_sd.keys():
            weight_map[k] = shard_name
            
        shard_count += 1
        del current_shard_sd
        import gc
        gc.collect()

    index_data = {
        "metadata": {"total_size": "140GB_approx"},
        "weight_map": weight_map
    }
    with open(os.path.join(config.output_dir, "model.safetensors.index.json"), "w") as f:
        json.dump(index_data, f, indent=2)

    print(f"Total Shards: {shard_count - 1}")
    print(f"Final Weights Location: {config.output_dir}")
    print("You can now load this model using HuggingFace 'from_pretrained' with a custom configuration.")
    print("="*50)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Socrates 70B")
    parser.add_argument("--active_weights_path", type=str, required=True, help="Path to aligned 2B .pt file")
    parser.add_argument("--static_dict_path", type=str, required=True, help="Path to 68B .dat file")
    parser.add_argument("--output_dir", type=str, default="./mdt_70b_safetensors")
    
    parser.add_argument("--n_layers", type=int, default=24)
    parser.add_argument("--n_heads", type=int, default=16)
    parser.add_argument("--d_model", type=int, default=2048)
    parser.add_argument("--d_inner", type=int, default=8192)
    parser.add_argument("--num_experts", type=int, default=100000)
    
    config = parser.parse_args()
    stream_merge_to_shards(config)