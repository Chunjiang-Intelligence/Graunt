import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import os
import json
import math
from transformers import AutoTokenizer
from safetensors import safe_open
from typing import List, Tuple, Dict, Optional
from mdt_core import (
    lift_minimal_coords, 
    gauge_fix, 
    solve_kl_step_newton, 
    apply_cayley_implicit,
    RoPE
)

class SocratesIncrementalCache:
    def __init__(self, n_layers, n_heads, n_kv_heads, d_head, device, dtype):
        self.n_layers = n_layers
        self.n_heads = n_heads
        self.n_kv_heads = n_kv_heads
        self.d_head = d_head
        self.device = device
        self.dtype = dtype
        
        self.k_cache = [None] * n_layers
        self.v_cache = [None] * n_layers
        
        self.u_cache = None # [B, T, H, D_head]
        self.m_att_cache = None # [B, T, H, D_head-1]
        self.m_ffn_cache = None # [B, T, H, D_head-1]

    def update_kv(self, layer_idx, k, v):
        if self.k_cache[layer_idx] is None:
            self.k_cache[layer_idx] = k
            self.v_cache[layer_idx] = v
        else:
            self.k_cache[layer_idx] = torch.cat([self.k_cache[layer_idx], k], dim=1)
            self.v_cache[layer_idx] = torch.cat([self.v_cache[layer_idx], v], dim=1)
        return self.k_cache[layer_idx], self.v_cache[layer_idx]

class ExpertWeightPool:
    def __init__(self, model_dir, config, device):
        self.device = device
        self.model_dir = model_dir
        self.n_layers = config['n_layers']
        self.num_experts = config['num_experts']
        self.d_inner = config['d_inner']
        self.d_model = config['d_model']
        
        # 建立索引映射
        index_path = os.path.join(model_dir, "model.safetensors.index.json")
        with open(index_path, "r") as f:
            self.weight_map = json.load(f)["weight_map"]
        
        # 缓存已打开的文件句柄
        self.shard_handles = {}
        # 显存内的热专家缓存
        self.gpu_cache = {}
        self.cache_limit = 500 # 限制显存内专家数量

    def get_expert_weight(self, layer_idx, expert_id):
        key = f"layers.{layer_idx}.moe.experts.{expert_id}.weight"
        cache_key = (layer_idx, expert_id)
        
        if cache_key in self.gpu_cache:
            return self.gpu_cache[cache_key]
        
        shard_name = self.weight_map[key]
        if shard_name not in self.shard_handles:
            self.shard_handles[shard_name] = safe_open(
                os.path.join(self.model_dir, shard_name), 
                framework="pt", device="cpu"
            )
        
        # 从磁盘分片读取并搬运到 GPU
        w = self.shard_handles[shard_name].get_tensor(key).to(self.device).half()
        
        if len(self.gpu_cache) > self.cache_limit:
            self.gpu_cache.pop(next(iter(self.gpu_cache)))
        self.gpu_cache[cache_key] = w
        return w

class SocratesInferenceEngine:
    def __init__(self, model_dir, device="cuda"):
        self.device = device
        self.model_dir = model_dir
        self.tokenizer = AutoTokenizer.from_pretrained(model_dir)
        
        # 加载配置
        with open(os.path.join(model_dir, "config.json"), "r") as f:
            self.config = json.load(f)
        
        self.d_model = self.config['d_model']
        self.n_heads = self.config['n_heads']
        self.d_head = self.d_model // self.n_heads
        self.m_planes = self.d_head // 2

        # 1. 初始化动态权重
        self.model = self._init_active_model()
        self._load_active_weights()
        
        # 2. 初始化专家池
        self.expert_pool = ExpertWeightPool(model_dir, self.config, device)
        
        # 3. 初始化 RoPE
        self.rope = RoPE(self.d_head, max_seq_len=8192).to(device)

    def _init_active_model(self):
        # 仅初始化包含线性层和 Norm 的骨干，MoE 部分通过 pool 动态调用
        from mdt_core import CredalTransformerV2
        model = CredalTransformerV2(
            vocab_size=self.config['vocab_size'],
            d_model=self.config['d_model'],
            n_heads=self.config['n_heads'],
            n_kv_heads=self.config['n_kv_heads'],
            n_layers=self.config['n_layers'],
            num_experts=self.config['num_experts'],
            mmap_path=None
        ).to(self.device).half()
        return model

    def _load_active_weights(self):
        # 从分片中加载非专家权重
        index_path = os.path.join(self.model_dir, "model.safetensors.index.json")
        with open(index_path, "r") as f:
            weight_map = json.load(f)["weight_map"]
        
        unique_shards = set([v for k, v in weight_map.items() if "moe.experts" not in k])
        for shard_name in unique_shards:
            with safe_open(os.path.join(self.model_dir, shard_name), framework="pt", device=self.device) as f:
                for key in f.keys():
                    if "moe.experts" not in key:
                        tensor = f.get_tensor(key).half()
                        self._set_param_by_name(key, tensor)

    def _set_param_by_name(self, name, tensor):
        elems = name.split('.')
        obj = self.model
        for i in range(len(elems) - 1):
            obj = getattr(obj, elems[i])
        setattr(obj, elems[-1], nn.Parameter(tensor, requires_grad=False))

    @torch.no_grad()
    def step_forward(self, input_ids, cache: SocratesIncrementalCache, pos: int):
        B, T_new = input_ids.shape
        x = self.model.tok_emb(input_ids) * math.sqrt(self.d_model)
        
        # 初始化当前步的几何状态 u (基于输入 embedding)
        # u_geom: [B, T_new, H, D_head]
        u_geom = lift_minimal_coords(torch.zeros(B, T_new, self.n_heads, self.d_head-1, device=self.device).half())
        u_geom = u_geom + x.view(B, T_new, self.n_heads, self.d_head)
        
        m_att = torch.zeros(B, T_new, self.n_heads, self.d_head-1, device=self.device).half()
        m_ffn = torch.zeros_like(m_att)

        for i, layer in enumerate(self.model.layers):
            x_feat = layer.attn_norm(u_geom.flatten(2)) # [B, T_new, D_model]
            
            q = layer.attn.W_q(x_feat).view(B, T_new, self.n_heads, self.d_head)
            k = layer.attn.W_k(x_feat).view(B, T_new, layer.attn.n_kv_heads, self.d_head)
            v = layer.attn.W_v(x_feat).view(B, T_new, layer.attn.n_kv_heads, self.d_head)
            
            # 应用位置编码
            q = self.rope(q, offset=pos)
            k = self.rope(k, offset=pos)
            
            # 更新并获取全量 KV Cache
            k_full, v_full = cache.update_kv(i, k, v)
            
            # 计算注意力
            k_exp = k_full.repeat_interleave(layer.attn.n_rep, dim=2)
            v_exp = v_full.repeat_interleave(layer.attn.n_rep, dim=2)
            
            # 推理时不使用 FlashAttn2 (针对单 token 效率)
            scores = torch.einsum('bthd,bshd->bhts', q, k_exp) / math.sqrt(self.d_head)
            # 仅在 prefill 阶段需要 mask
            if T_new > 1:
                mask = torch.triu(torch.ones(T_new, T_new, device=self.device, dtype=torch.bool), 1)
                scores[..., -T_new:, -T_new:].masked_fill_(mask, -float('inf'))
            
            alpha = F.softmax(scores.float(), dim=-1).to(q.dtype)
            attn_out = torch.einsum('bhts,bshd->bthd', alpha, v_exp).reshape(B, T_new, self.d_model)
            
            e_att = layer.attn.W_o(attn_out).view(B, T_new, self.n_heads, self.d_head)
            delta_s_att = e_att[..., :-1]
            
            # 这里的 m_att 逻辑在推理时需要从历史累积
            g_u_att = lift_minimal_coords(delta_s_att)
            pi = F.softmax(u_geom.float(), dim=-1).to(u_geom.dtype)
            g_att = gauge_fix((1e-5 + pi * (1-pi)) * g_u_att)
            
            eta = solve_kl_step_newton(u_geom, g_att, kappa=0.01)
            u_geom = u_geom + eta * g_att
            
            x_feat_ffn = layer.ffn_norm(u_geom.flatten(2))
            # LSH 路由
            hashes = torch.sign(x_feat_ffn @ layer.moe.hash_vectors)
            expert_ids = ((hashes > 0).long() * (2 ** torch.arange(16, device=self.device))).sum(dim=-1) % 100000
            
            moe_out = torch.zeros_like(x_feat_ffn)
            for b in range(B):
                for t in range(T_new):
                    e_id = expert_ids[b, t].item()
                    w_expert = self.expert_pool.get_expert_weight(i, e_id)
                    # 执行专家计算
                    gate = F.silu(layer.w1(x_feat_ffn[b, t]))
                    moe_out[b, t] = (gate * (x_feat_ffn[b, t] @ w_expert.T)) @ w_expert
            
            e_ffn = layer.w2(moe_out).view(u_geom.shape)
            delta_s_ffn = e_ffn[..., :-1]
            g_ffn = gauge_fix(lift_minimal_coords(delta_s_ffn))
            eta_ffn = solve_kl_step_newton(u_geom, g_ffn, kappa=0.01)
            u_geom = u_geom + eta_ffn * g_ffn

        # 输出层
        logits = self.model.lm_head(self.model.final_norm(u_geom.flatten(2)))
        return logits, cache

    def chat(self, system_prompt, user_input, max_len=512):
        prompt = f"<|user|>\n{system_prompt}\n{user_input}\n<|assistant|>\n"
        tokens = self.tokenizer.encode(prompt, return_tensors="pt").to(self.device)
        
        cache = SocratesIncrementalCache(
            self.config['n_layers'], self.n_heads, self.config['n_kv_heads'], 
            self.d_head, self.device, torch.float16
        )
        
        generated = []
        curr_pos = 0
        
        # Prefill 阶段
        logits, cache = self.step_forward(tokens, cache, curr_pos)
        curr_pos += tokens.shape[1]
        next_token = torch.argmax(logits[:, -1, :], dim=-1)
        generated.append(next_token.item())
        
        # Decoding 阶段
        print("Socrates: ", end="", flush=True)
        for _ in range(max_len):
            word = self.tokenizer.decode([generated[-1]])
            print(word, end="", flush=True)
            if generated[-1] == self.tokenizer.eos_token_id:
                break
            
            logits, cache = self.step_forward(
                torch.tensor([[generated[-1]]], device=self.device), 
                cache, curr_pos
            )
            curr_pos += 1
            next_token = torch.argmax(logits[:, -1, :], dim=-1)
            generated.append(next_token.item())
        print("\n")

if __name__ == "__main__":
    # 配置模型目录 (需包含合并后的 safetensors, index.json, tokenizer, config.json)
    MODEL_PATH = "./mdt_final_release"
    
    if not os.path.exists(os.path.join(MODEL_PATH, "config.json")):
        with open(os.path.join(MODEL_PATH, "config.json"), "w") as f:
            json.dump({
                "d_model": 2048, "n_heads": 16, "n_kv_heads": 4, 
                "n_layers": 24, "vocab_size": 32000, "num_experts": 100000, "d_inner": 8192
            }, f)

    engine = SocratesInferenceEngine(MODEL_PATH)
    engine.chat(
        system_prompt="你是由春江智能开发的大型语言模型 Socrates。请用辩证法回答问题。",
        user_input="请问什么是真理？"
    )