import torch
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader, IterableDataset
from torch.optim.lr_scheduler import CosineAnnealingLR
from datasets import load_dataset
from transformers import AutoTokenizer
from mdt_core import CredalTransformerV2
import os
import time
import math
from tqdm import tqdm

class TrainConfig:
    # Model Params
    D_MODEL = 2048
    N_LAYERS = 24
    N_HEADS = 16
    N_KV_HEADS = 4
    VOCAB_SIZE = 32000
    NUM_EXPERTS = 100000
    
    # Training Params
    BATCH_SIZE = 8
    SEQ_LEN = 2048
    LEARNING_RATE = 3e-4
    WEIGHT_DECAY = 0.1
    GRAD_CLIP = 1.0
    DEVICE = "cuda"
    DTYPE = torch.bfloat16
    
    # LR Scheduler
    WARMUP_STEPS = 2000
    MAX_STEPS = 200000
    LR_MIN = 3e-5
    
    # Data & I/O
    MEMMAP_FILE = "mdt_68b_experts.dat"
    CHECKPOINT_DIR = "./mdt_checkpoints"
    LOG_INTERVAL = 10
    VALIDATION_INTERVAL = 500
    
class StreamingCollator:
    def __init__(self, tokenizer, max_length):
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __call__(self, batch):
        texts = [item['text'] for item in batch if item['text']]
        if not texts: return None, None
        
        enc = self.tokenizer(texts, truncation=True, max_length=self.max_length + 1, padding=False, return_tensors="pt")
        all_tokens = enc.input_ids.flatten()
        num_chunks = len(all_tokens) // self.max_length
        if num_chunks == 0: return None, None
        
        all_tokens = all_tokens[:num_chunks * self.max_length]
        chunks = all_tokens.view(-1, self.max_length)
        
        input_ids = chunks[:, :-1]
        labels = chunks[:, 1:]
        return input_ids, labels

class MDTTrainer:
    def __init__(self, config):
        self.config = config
        os.makedirs(config.CHECKPOINT_DIR, exist_ok=True)
        
        # Model
        self.model = CredalTransformerV2(
            vocab_size=config.VOCAB_SIZE, d_model=config.D_MODEL, n_heads=config.N_HEADS,
            n_kv_heads=config.N_KV_HEADS, n_layers=config.N_LAYERS,
            num_experts=config.NUM_EXPERTS, mmap_path=config.MEMMAP_FILE
        ).to(config.DEVICE)
        
        # Optimizer
        self.optimizer = self.configure_optimizer()
        
        # LR Scheduler
        self.scheduler = CosineAnnealingLR(self.optimizer, T_max=config.MAX_STEPS - config.WARMUP_STEPS, eta_min=config.LR_MIN)
        
        # AMP Scaler
        self.scaler = torch.cuda.amp.GradScaler(enabled=(self.config.DTYPE == torch.float16))
        
        # Data
        self.tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-v0.1")
        self.tokenizer.pad_token = self.tokenizer.eos_token

    def configure_optimizer(self):
        param_dict = {pn: p for pn, p in self.model.named_parameters() if p.requires_grad and "moe." not in pn}
        decay_params = [p for n, p in param_dict.items() if p.dim() >= 2]
        nodecay_params = [p for n, p in param_dict.items() if p.dim() < 2]
        optim_groups = [
            {'params': decay_params, 'weight_decay': self.config.WEIGHT_DECAY},
            {'params': nodecay_params, 'weight_decay': 0.0}
        ]
        return optim.AdamW(optim_groups, lr=self.config.LEARNING_RATE, betas=(0.9, 0.95), fused=True)

    def get_lr(self, step):
        if step < self.config.WARMUP_STEPS:
            return self.config.LEARNING_RATE * (step + 1) / self.config.WARMUP_STEPS
        # After warmup, CosineAnnealingLR handles it
        return self.scheduler.get_last_lr()[0]

    def train(self):
        train_ds = load_dataset("HuggingFaceFW/fineweb-edu", name="sample-10BT", split="train", streaming=True)
        val_ds = load_dataset("HuggingFaceFW/fineweb-edu", name="sample-10BT", split="validation", streaming=True).take(100)
        
        collator = StreamingCollator(self.tokenizer, self.config.SEQ_LEN)
        train_loader = DataLoader(train_ds, batch_size=self.config.BATCH_SIZE, collate_fn=collator, num_workers=4)
        
        step = 0
        best_val_loss = float('inf')
        
        self.model.train()
        
        for input_ids, labels in train_loader:
            if input_ids is None or step >= self.config.MAX_STEPS:
                break
                
            lr = self.get_lr(step)
            for param_group in self.optimizer.param_groups:
                param_group['lr'] = lr

            input_ids, labels = input_ids.to(self.config.DEVICE), labels.to(self.config.DEVICE)
            
            with torch.autocast(device_type=self.config.DEVICE, dtype=self.config.DTYPE):
                logits = self.model(input_ids)
                loss = F.cross_entropy(logits.view(-1, self.config.VOCAB_SIZE), labels.view(-1))
            
            self.scaler.scale(loss).backward()
            
            # Gradient Clipping 为了 Looped
            self.scaler.unscale_(self.optimizer)
            grad_norm = torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.GRAD_CLIP)
            
            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.optimizer.zero_grad(set_to_none=True)
            
            if step >= self.config.WARMUP_STEPS:
                self.scheduler.step()
            
            if step % self.config.LOG_INTERVAL == 0:
                print(f"Step {step:6d} | Loss: {loss.item():.4f} | LR: {lr:.2e} | Grad Norm: {grad_norm:.4f}")
            
            if step > 0 and step % self.config.VALIDATION_INTERVAL == 0:
                val_loss = self.validate(val_ds, collator)
                print(f"--- Validation at Step {step}: Loss = {val_loss:.4f} ---")
                if val_loss < best_val_loss:
                    best_val_loss = val_loss
                    checkpoint_path = os.path.join(self.config.CHECKPOINT_DIR, f"mdt_step_{step}_loss_{val_loss:.2f}.pt")
                    torch.save(self.model.state_dict(), checkpoint_path)
                    print(f"New best model saved to {checkpoint_path}")
                self.model.train()
            
            step += 1

    @torch.no_grad()
    def validate(self, val_ds, collator):
        self.model.eval()
        total_loss = 0
        count = 0
        
        val_loader = DataLoader(val_ds, batch_size=self.config.BATCH_SIZE, collate_fn=collator)
        for input_ids, labels in val_loader:
            if input_ids is None: continue
            input_ids, labels = input_ids.to(self.config.DEVICE), labels.to(self.config.DEVICE)
            
            with torch.autocast(device_type=self.config.DEVICE, dtype=self.config.DTYPE):
                logits = self.model(input_ids)
                loss = F.cross_entropy(logits.view(-1, self.config.VOCAB_SIZE), labels.view(-1))
            
            total_loss += loss.item() * input_ids.size(0)
            count += input_ids.size(0)
            
        return total_loss / count if count > 0 else float('inf')


if __name__ == "__main__":
    config = TrainConfig()
    trainer = MDTTrainer(config)
    trainer.train()