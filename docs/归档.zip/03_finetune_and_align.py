import torch
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from datasets import load_dataset, concatenate_datasets
from transformers import AutoTokenizer
from mdt_core import CredalTransformerV2
from peft_utils import apply_peft
import os
import argparse
from tqdm import tqdm
import math

class ChatTemplateProcessor:
    def __init__(self, tokenizer, max_length=2048):
        self.tokenizer = tokenizer
        self.max_length = max_length
        if self.tokenizer.chat_template is None:
            self.tokenizer.chat_template = "{% for message in messages %}\n{% if message['role'] == 'user' %}\n{{ '<|user|>\n' + message['content'] + eos_token }}\n{% elif message['role'] == 'assistant' %}\n{{ '<|assistant|>\n'  + message['content'] + eos_token }}\n{% endif %}\n{% endfor %}"

    def process_sft(self, examples):
        batch_outputs = {'input_ids': [], 'labels': []}
        for conversation in examples['messages']:
            tokenized_text = self.tokenizer.apply_chat_template(conversation, tokenize=True, add_generation_prompt=False)
            
            labels = list(tokenized_text)
            
            assistant_token_id = self.tokenizer.convert_tokens_to_ids('<|assistant|>') if '<|assistant|>' in self.tokenizer.vocab else None
            user_token_id = self.tokenizer.convert_tokens_to_ids('<|user|>') if '<|user|>' in self.tokenizer.vocab else None

            if assistant_token_id and user_token_id:
                is_assistant_turn = False
                for i in range(len(tokenized_text)):
                    if tokenized_text[i] == assistant_token_id:
                        is_assistant_turn = True
                    elif tokenized_text[i] == user_token_id or tokenized_text[i] == self.tokenizer.eos_token:
                        is_assistant_turn = False
                    
                    if not is_assistant_turn:
                        labels[i] = -100
                        
            batch_outputs['input_ids'].append(torch.tensor(tokenized_text[:self.max_length]))
            batch_outputs['labels'].append(torch.tensor(labels[:self.max_length]))
        
        return batch_outputs

def dpo_loss(policy_chosen_logps, policy_rejected_logps,
             reference_chosen_logps, reference_rejected_logps, beta=0.1):
    pi_logratios = policy_chosen_logps - policy_rejected_logps
    ref_logratios = reference_chosen_logps - reference_rejected_logps
    return -F.logsigmoid(beta * (pi_logratios - ref_logratios)).mean()

class FinetuningEngine:
    def __init__(self, config):
        self.config = config
        self.device = "cuda"
        os.makedirs(config.output_dir, exist_ok=True)
        
        # Tokenizer & Data Processor
        self.tokenizer = AutoTokenizer.from_pretrained(config.tokenizer_path)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.processor = ChatTemplateProcessor(self.tokenizer, config.max_seq_len)

        # Base Model
        print("Loading base MDT model for finetuning...")
        self.model = CredalTransformerV2(mmap_path="mdt_68b_experts.dat").to(self.device)
        self.model.load_state_dict(torch.load(config.base_model_path, map_location=self.device), strict=False)

        # Apply PEFT if specified
        if config.mode != 'sft':
            self.model = apply_peft(self.model, peft_method=config.mode, r=config.lora_r, alpha=config.lora_alpha)
        
        # DPO requires a reference model
        if config.mode == 'dpo':
            print("Loading reference model for DPO...")
            self.ref_model = CredalTransformerV2(mmap_path="mdt_68b_experts.dat").to(self.device)
            self.ref_model.load_state_dict(torch.load(config.base_model_path, map_location=self.device), strict=False)
            self.ref_model.eval()

    def run_sft(self):
        # Data loading for SFT
        dataset = load_dataset(self.config.dataset_name, split="train_sft[:20000]") # Use a subset for demo
        processed_dataset = dataset.map(self.processor.process_sft, batched=True, remove_columns=dataset.column_names)
        
        # Custom collator for padding
        def collate_fn(batch):
            input_ids = [item['input_ids'] for item in batch]
            labels = [item['labels'] for item in batch]
            padded_inputs = torch.nn.utils.rnn.pad_sequence(input_ids, batch_first=True, padding_value=self.tokenizer.pad_token_id)
            padded_labels = torch.nn.utils.rnn.pad_sequence(labels, batch_first=True, padding_value=-100)
            return {'input_ids': padded_inputs, 'labels': padded_labels}

        dataloader = DataLoader(processed_dataset, batch_size=self.config.batch_size, collate_fn=collate_fn, shuffle=True)
        optimizer = optim.AdamW(self.model.parameters(), lr=self.config.lr)
        
        print(f"--- Starting SFT for {self.config.epochs} epochs ---")
        self.model.train()
        for epoch in range(self.config.epochs):
            pbar = tqdm(dataloader, desc=f"SFT Epoch {epoch+1}")
            for batch in pbar:
                optimizer.zero_grad()
                inputs = batch['input_ids'].to(self.device)
                labels = batch['labels'].to(self.device)

                with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                    logits = self.model(inputs)
                    loss = F.cross_entropy(logits.view(-1, logits.size(-1)), labels.view(-1))
                
                loss.backward()
                optimizer.step()
                pbar.set_postfix({"loss": loss.item()})
        
        self.save_model()

    @torch.no_grad()
    def get_log_probs(self, model, input_ids, labels):
        logits = model(input_ids)
        log_probs = F.log_softmax(logits, dim=-1)
        return torch.gather(log_probs, -1, labels.unsqueeze(-1)).squeeze(-1)

    def run_dpo(self):
        dataset = load_dataset(self.config.dataset_name, split="train[:5000]")
        optimizer = optim.AdamW(filter(lambda p: p.requires_grad, self.model.parameters()), lr=self.config.lr)

        print(f"--- Starting DPO for {self.config.epochs} epochs ---")
        self.model.train()
        for epoch in range(self.config.epochs):
            pbar = tqdm(dataset, desc=f"DPO Epoch {epoch+1}")
            for example in pbar:
                optimizer.zero_grad()
                
                prompt_tokens = self.tokenizer(example['prompt'], return_tensors='pt').input_ids.to(self.device)
                chosen_tokens = self.tokenizer(example['chosen'], return_tensors='pt').input_ids.to(self.device)
                rejected_tokens = self.tokenizer(example['rejected'], return_tensors='pt').input_ids.to(self.device)

                chosen_ids = torch.cat([prompt_tokens, chosen_tokens], dim=-1)
                rejected_ids = torch.cat([prompt_tokens, rejected_tokens], dim=-1)
                
                with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                    policy_chosen_logps = self.get_log_probs(self.model, chosen_ids, chosen_tokens)
                    policy_rejected_logps = self.get_log_probs(self.model, rejected_ids, rejected_tokens)
                    
                    ref_chosen_logps = self.get_log_probs(self.ref_model, chosen_ids, chosen_tokens)
                    ref_rejected_logps = self.get_log_probs(self.ref_model, rejected_ids, rejected_tokens)
                
                loss = dpo_loss(policy_chosen_logps, policy_rejected_logps, ref_chosen_logps.detach(), ref_rejected_logps.detach())
                loss.backward()
                optimizer.step()
                pbar.set_postfix({"dpo_loss": loss.item()})

        self.save_model()

    def save_model(self):
        output_path = os.path.join(self.config.output_dir, f"mdt_final_{self.config.mode}.pt")
        
        if self.config.mode in ['lora', 'dora']:
            print("Merging PEFT weights before saving...")
            if hasattr(self.model, 'merge_and_unload'):
                self.model = self.model.merge_and_unload()
        
        torch.save(self.model.state_dict(), output_path)
        print(f"Final model saved to {output_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Industrial-Grade Finetuning for MDT-70B")
    parser.add_argument("--mode", type=str, default="lora", choices=['sft', 'lora', 'dora', 'dpo'], help="Finetuning mode")
    parser.add_argument("--base_model_path", type=str, default="mdt_2b_active_final.pt", help="Path to the pretrained 2B active weights")
    parser.add_argument("--dataset_name", type=str, default="HuggingFaceH4/ultrachat_200k", help="Dataset from Hugging Face Hub")
    parser.add_argument("--tokenizer_path", type=str, default="mistralai/Mistral-7B-v0.1")
    parser.add_argument("--output_dir", type=str, default="./mdt_finetuned")
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--batch_size", type=int, default=2)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--max_seq_len", type=int, default=2048)
    parser.add_argument("--lora_r", type=int, default=16)
    parser.add_argument("--lora_alpha", type=int, default=32)
    
    config = parser.parse_args()
    
    engine = FinetuningEngine(config)
    
    if config.mode == 'dpo':
        config.dataset_name = "Intel/orca_dpo_pairs"
        engine.run_dpo()
    else: # sft, lora, dora
        engine.run_sft()